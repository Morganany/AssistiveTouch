# Assistive Touch

Tombol melayang bergaya iOS untuk Android dengan menu kaca (glass blur). Ringan, tanpa library tambahan, tanpa izin internet.

## Fitur

- Tombol melayang yang bisa digeser, otomatis menempel ke tepi layar, dan memudar saat tidak disentuh.
- Menu 3x3 bergaya kaca: Notifikasi, Pusat Kontrol, Kembali, Kunci Layar, Home, Aplikasi Terbaru, Screenshot, Volume, Daya.
- Blur latar belakang asli di Android 12 ke atas (blur lintas jendela). Di Android lama (minSdk 22 / Android 5.1) memakai kaca transparan dengan dim sebagai pengganti.
- Ukuran tombol, transparansi saat diam, dan getaran bisa diatur.
- Bahasa Inggris dan Indonesia.

## Kenapa hemat RAM

- Hanya satu AccessibilityService. Tidak ada foreground service, notifikasi permanen, timer berulang, atau receiver.
- Service tidak mendengarkan event aplikasi lain sama sekali.
- Menu dibuat saat dibuka dan dibuang saat ditutup.
- Tombol digambar dengan Canvas dan ikon berupa vektor, tanpa bitmap.
- Tidak memakai AndroidX atau library UI lain.

## Build lewat GitHub

1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (atau `git push`).
2. Buka tab Actions. Workflow "Build APK" berjalan otomatis setiap push.
3. Setelah selesai, buka run tersebut dan unduh artifact `AssistiveTouch-apk` (berisi APK release dan debug).
4. Untuk membuat halaman Release: buat tag, contoh `git tag v1.0.0 && git push origin v1.0.0`. APK otomatis dilampirkan.

APK release ditandatangani dengan debug key supaya bisa langsung dipasang. Karena key ini dibuat ulang oleh setiap runner GitHub, update antar build bisa gagal dengan pesan tanda tangan berbeda. Jika itu terjadi, hapus versi lama lalu pasang ulang. Untuk tanda tangan tetap, buat keystore sendiri dan simpan di GitHub Secrets.

## Cara memakai

1. Pasang APK, buka aplikasi, ketuk Buka pengaturan Aksesibilitas.
2. Pilih Assistive Touch lalu nyalakan.
3. Android 13 ke atas: jika opsi abu-abu, buka Info aplikasi, titik tiga di kanan atas, pilih Izinkan pengaturan terbatas.

## Privasi

Aplikasi tidak meminta izin internet, tidak membaca isi layar, dan tidak mengumpulkan data. Layanan aksesibilitas hanya dipakai untuk aksi global (Home, Kembali, dan sebagainya).

## Lisensi

MIT License. Lihat berkas [LICENSE](LICENSE). Copyright (c) 2026 Muhammad Zidan (Morganany).

## Catatan kompatibilitas

- Kunci Layar dan Screenshot memerlukan Android 9 ke atas. Di versi lebih lama ikonnya dinonaktifkan.
- Beberapa pabrikan membatasi blur lintas jendela saat mode hemat daya. Menu otomatis memakai tampilan pengganti.
