# Assistive Touch

Tombol melayang bergaya iOS untuk Android dengan menu kaca (glass blur). Ringan, tanpa library tambahan, tanpa izin internet.

## Fitur

- Tombol melayang yang bisa digeser, otomatis menempel ke tepi layar, dan memudar saat tidak disentuh.
- Menu 3x3 bergaya kaca: Notifikasi, Pusat Kontrol, Kembali, Kunci Layar, Home, Aplikasi Terbaru, Screenshot, Volume, Daya.
- Blur latar belakang asli di Android 12 ke atas (blur lintas jendela). Di Android lama (minSdk 22 / Android 5.1) memakai kaca transparan dengan dim sebagai pengganti.
- Ukuran tombol, transparansi saat diam, dan getaran bisa diatur.
- Bahasa Inggris dan Indonesia.

## Baru di 1.4.0

- **Tombol melayang bulat.** Lingkaran gelap dengan dua cincin abu-abu dan inti putih. Inti berubah hijau saat Booster aktif.
- **Menu bertumpuk seperti iOS.** Tombol Lainnya membuka panel kedua yang menumpuk di atas menu utama; menu utama mengecil dan bergeser ke belakang. Isi folder diatur di aplikasi (grid Isi folder Lainnya). Slot tengah selalu Kembali, dan folder tidak bisa berisi folder.
- **Booster menyembunyikan notifikasi.** Saat Booster aktif, Jangan Ganggu mode prioritas menyembunyikan popup, suara, lampu, ikon status bar, dan isi daftar notifikasi. Media, alarm, dan panggilan tetap masuk. Pengaturan Jangan Ganggu Anda disimpan lalu dipulihkan saat Booster berakhir atau layanan dimulai ulang. Butuh akses Jangan Ganggu (tombol di aplikasi) dan bisa dimatikan lewat sakelar.

## Baru di 1.3.0

- **Tombol menu bisa diatur sendiri.** Di aplikasi, bagian Tombol menu menampilkan grid 3x3. Ketuk slot, pilih fungsinya. Memilih fungsi yang sudah ada di slot lain akan menukar keduanya. Ada tombol kembalikan ke bawaan.
- **Bersihkan RAM.** Menghentikan proses latar belakang aplikasi non-sistem dengan `killBackgroundProcesses`, lalu menampilkan jumlah aplikasi dan RAM yang dibebaskan. Aplikasi ini, peluncur home, keyboard aktif, dan game pilihan tidak ikut dihentikan. Aplikasi yang sedang tampil tidak tersentuh.
- **Booster Game.** Membersihkan RAM, menahan layar tetap menyala, memberi penanda hijau pada tombol melayang, dan membuka game pilihan (misalnya Roblox) bila diatur. Ketuk lagi untuk mengakhiri. Tanpa root, booster tidak bisa menaikkan kecepatan CPU atau GPU.
- **Kunci Rotasi.** Mengunci orientasi layar (tahan saat ini, potret, atau lanskap) lewat jendela overlay aksesibilitas 1 px, tanpa izin tambahan. Kunci dipasang ulang saat layanan dimulai lagi.

Tombol baru ini tidak ada di menu bawaan supaya tampilan lama tidak berubah. Pasang lewat Tombol menu di aplikasi.

## Kenapa hemat RAM

- Hanya satu AccessibilityService. Tidak ada foreground service, notifikasi permanen, timer berulang, atau receiver.
- Service tidak mendengarkan event aplikasi lain sama sekali.
- Menu dibuat saat dibuka dan dibuang saat ditutup.
- Tombol digambar dengan Canvas dan ikon berupa vektor, tanpa bitmap.
- Tidak memakai AndroidX atau library UI lain.

## Build lewat GitHub

1. Buat repository baru di GitHub, lalu upload seluruh isi folder ini (atau `git push`).
2. Buka tab Actions. Workflow "Build APK" berjalan otomatis setiap push.
3. Setelah selesai, buka run tersebut dan unduh artifact `AssistiveTouch-apk` (berisi APK release dan debug).
4. Untuk membuat halaman Release: buat tag, contoh `git tag v1.4.0 && git push origin v1.4.0`. APK otomatis dilampirkan.

APK release ditandatangani dengan debug key supaya bisa langsung dipasang. Karena key ini dibuat ulang oleh setiap runner GitHub, update antar build bisa gagal dengan pesan tanda tangan berbeda. Jika itu terjadi, hapus versi lama lalu pasang ulang. Untuk tanda tangan tetap, buat keystore sendiri dan simpan di GitHub Secrets.

## Cara memakai

1. Pasang APK, buka aplikasi, ketuk Buka pengaturan Aksesibilitas.
2. Pilih Assistive Touch lalu nyalakan.
3. Android 13 ke atas: jika opsi abu-abu, buka Info aplikasi, titik tiga di kanan atas, pilih Izinkan pengaturan terbatas.

## Blur dan tetap berjalan di latar belakang

- Di Android 11 ke atas, saat menu dibuka layar ditangkap sekali di memori, diburamkan, lalu dipakai sebagai latar kaca. Hasilnya tidak disimpan dan tidak dikirim. Di Android lama, menu memakai tampilan kaca transparan dengan dim.
- Tanpa notifikasi: layanan aksesibilitas tidak butuh foreground service. Menggeser aplikasi dari Recents tidak menghentikannya di Android standar. Beberapa pabrikan (ColorOS, MIUI, dan sejenisnya) mematikan proses agresif, jadi izinkan Autostart, kunci aplikasi di Recents, dan set baterai ke Tanpa batasan. Tombol di dalam aplikasi membantu bagian baterai.

## Privasi

Aplikasi tidak meminta izin internet dan tidak mengumpulkan data. Daftar aplikasi ber-ikon peluncur hanya dibaca di perangkat untuk pembersih RAM dan pilihan game, tidak disimpan dan tidak dikirim. Layanan aksesibilitas dipakai untuk aksi global (Home, Kembali, dan sebagainya) dan tangkapan layar sesaat di memori untuk efek blur.

## Lisensi

MIT License. Lihat berkas [LICENSE](LICENSE). Copyright (c) 2026 Muhammad Zidan (Morganany).

## Catatan kompatibilitas

- Kunci Layar dan Screenshot memerlukan Android 9 ke atas. Di versi lebih lama ikonnya dinonaktifkan.
- Pembersih RAM dan Booster memakai izin KILL_BACKGROUND_PROCESSES (izin biasa, otomatis diberikan). Hasilnya bergantung pabrikan: sebagian ROM menghidupkan lagi aplikasi yang dihentikan.
- Menyembunyikan notifikasi di Android 9 ke atas mencakup popup, ikon, dan daftar; di Android 6 sampai 8 hanya mode prioritas tanpa penekanan tampilan rinci.
- Kunci Rotasi memakai jendela overlay dengan screenOrientation. Jika ROM tertentu mengabaikannya, kunci tidak berefek.
- Beberapa pabrikan membatasi blur lintas jendela saat mode hemat daya. Menu otomatis memakai tampilan pengganti.
