# Tidak ada aturan khusus. Aplikasi tidak memakai library pihak ketiga.
