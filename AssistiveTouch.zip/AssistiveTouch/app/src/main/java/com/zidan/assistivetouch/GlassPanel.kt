package com.zidan.assistivetouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Region
import android.os.Build
import android.widget.LinearLayout

/**
 * Panel kaca menu. Saat panel lain menumpuk di atasnya (folder Lainnya), bagian yang tertutup
 * panel itu dilubangi supaya kartu di belakang tidak tembus terlihat lewat kaca transparan.
 * Hanya sisa tepi kartu yang menyembul di luar panel depan yang tetap tergambar.
 */
class GlassPanel(context: Context) : LinearLayout(context) {

    private val path = Path()
    private val rect = RectF()
    private var halfPx = 0f
    private var cornerPx = 0f
    private var scale = 1f
    private var shiftPx = 0f

    /** 0 sampai 1: seberapa penuh lubang dibuat (dianimasikan saat folder dibuka atau ditutup). */
    var cutAmount: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    /**
     * Ukuran panel depan (setengah sisi dan radius sudut), serta skala dan geser akhir panel ini.
     * shiftPx berupa nilai translationY akhir, negatif jika panel bergeser ke atas.
     */
    fun configureCutout(halfPx: Float, cornerPx: Float, scale: Float, shiftPx: Float) {
        this.halfPx = halfPx
        this.cornerPx = cornerPx
        this.scale = scale
        this.shiftPx = shiftPx
    }

    @Suppress("DEPRECATION")
    override fun draw(canvas: Canvas) {
        if (cutAmount <= 0f || halfPx <= 0f) {
            super.draw(canvas)
            return
        }
        // Petakan batas panel depan (koordinat layar) ke koordinat lokal panel ini yang sudah
        // diskalakan dan digeser.
        val cx = width / 2f
        val cy = height / 2f
        val l = cx - halfPx / scale
        val r = cx + halfPx / scale
        val t = cy + (-halfPx - shiftPx) / scale
        val b = cy + (halfPx - shiftPx) / scale
        val a = cutAmount
        val mx = (l + r) / 2f
        val my = (t + b) / 2f
        rect.set(mx + (l - mx) * a, my + (t - my) * a, mx + (r - mx) * a, my + (b - my) * a)
        val radius = cornerPx / scale * a
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)

        canvas.save()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            canvas.clipOutPath(path)
        } else {
            canvas.clipPath(path, Region.Op.DIFFERENCE)
        }
        super.draw(canvas)
        canvas.restore()
    }
}
