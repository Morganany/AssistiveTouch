package com.zidan.assistivetouch

import android.content.SharedPreferences

/** Daftar fungsi yang bisa dipasang ke 9 slot menu. Urutan slot disimpan di Prefs.SLOTS. */
object Actions {

    class Def(val id: String, val label: Int, val icon: Int)

    const val NONE = "none"
    const val SLOT_COUNT = 9

    val ALL = listOf(
        Def("notifications", R.string.label_notifications, R.drawable.ic_notifications),
        Def("control", R.string.label_control, R.drawable.ic_control),
        Def("back", R.string.label_back, R.drawable.ic_back),
        Def("lock", R.string.label_lock, R.drawable.ic_lock),
        Def("home", R.string.label_home, R.drawable.ic_home),
        Def("recents", R.string.label_recents, R.drawable.ic_recents),
        Def("screenshot", R.string.label_screenshot, R.drawable.ic_screenshot),
        Def("volume", R.string.label_volume, R.drawable.ic_volume),
        Def("power", R.string.label_power, R.drawable.ic_power),
        Def("rotate", R.string.label_rotate, R.drawable.ic_rotate),
        Def("clean", R.string.label_clean, R.drawable.ic_clean),
        Def("boost", R.string.label_boost, R.drawable.ic_boost),
        Def(NONE, R.string.label_none, R.drawable.ic_empty)
    )

    val DEFAULT = listOf(
        "notifications", "control", "back",
        "lock", "home", "recents",
        "screenshot", "volume", "power"
    )

    fun find(id: String): Def = ALL.firstOrNull { it.id == id } ?: ALL.last()

    fun load(prefs: SharedPreferences): MutableList<String> {
        val saved = prefs.getString(Prefs.SLOTS, null)?.split(',')
        val list = (saved ?: DEFAULT).toMutableList()
        while (list.size < SLOT_COUNT) list.add(NONE)
        return list.take(SLOT_COUNT).map { id -> if (ALL.any { it.id == id }) id else NONE }.toMutableList()
    }

    fun save(prefs: SharedPreferences, slots: List<String>) {
        prefs.edit().putString(Prefs.SLOTS, slots.joinToString(",")).apply()
    }

    fun reset(prefs: SharedPreferences) {
        prefs.edit().remove(Prefs.SLOTS).apply()
    }
}
