package com.zidan.assistivetouch

import android.app.NotificationManager
import android.content.Context
import android.os.Build

/**
 * Mode senyap untuk Booster. Memakai Jangan Ganggu (prioritas) agar notifikasi masuk tidak muncul
 * sebagai popup, suara, lampu, ikon status bar, maupun isi bayangan notifikasi. Media, alarm, dan
 * panggilan tetap lolos. Pengaturan Jangan Ganggu milik pengguna disimpan dulu, lalu dipulihkan saat
 * Booster berhenti atau layanan dimulai ulang. Butuh akses Jangan Ganggu yang diberikan pengguna.
 */
object QuietMode {

    private const val SAVED = "quiet_saved"

    private fun nm(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun hasAccess(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && nm(ctx).isNotificationPolicyAccessGranted

    fun enter(ctx: Context): Boolean {
        if (!hasAccess(ctx)) return false
        val prefs = Prefs.get(ctx)
        return try {
            val nm = nm(ctx)
            if (!prefs.contains(SAVED)) {
                val p = nm.notificationPolicy
                val fx = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) p.suppressedVisualEffects else 0
                val saved = listOf(
                    nm.currentInterruptionFilter, p.priorityCategories,
                    p.priorityCallSenders, p.priorityMessageSenders, fx
                ).joinToString(",")
                prefs.edit().putString(SAVED, saved).apply()
            }
            nm.notificationPolicy = quietPolicy()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun exit(ctx: Context) {
        val prefs = Prefs.get(ctx)
        val saved = prefs.getString(SAVED, null) ?: return
        try {
            val v = saved.split(',').map { it.toInt() }
            if (hasAccess(ctx)) {
                val nm = nm(ctx)
                nm.notificationPolicy =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        NotificationManager.Policy(v[1], v[2], v[3], v[4])
                    } else {
                        NotificationManager.Policy(v[1], v[2], v[3])
                    }
                if (v[0] != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) {
                    nm.setInterruptionFilter(v[0])
                }
            }
        } catch (e: Exception) {
            // abaikan, pengguna tetap bisa mematikan Jangan Ganggu sendiri
        }
        prefs.edit().remove(SAVED).apply()
    }

    private fun quietPolicy(): NotificationManager.Policy {
        val any = NotificationManager.Policy.PRIORITY_SENDERS_ANY
        var categories = NotificationManager.Policy.PRIORITY_CATEGORY_CALLS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            categories = categories or
                NotificationManager.Policy.PRIORITY_CATEGORY_MEDIA or
                NotificationManager.Policy.PRIORITY_CATEGORY_ALARMS
            val fx = NotificationManager.Policy.SUPPRESSED_EFFECT_SCREEN_OFF or
                NotificationManager.Policy.SUPPRESSED_EFFECT_SCREEN_ON or
                NotificationManager.Policy.SUPPRESSED_EFFECT_FULL_SCREEN_INTENT or
                NotificationManager.Policy.SUPPRESSED_EFFECT_LIGHTS or
                NotificationManager.Policy.SUPPRESSED_EFFECT_PEEK or
                NotificationManager.Policy.SUPPRESSED_EFFECT_STATUS_BAR or
                NotificationManager.Policy.SUPPRESSED_EFFECT_BADGE or
                NotificationManager.Policy.SUPPRESSED_EFFECT_AMBIENT or
                NotificationManager.Policy.SUPPRESSED_EFFECT_NOTIFICATION_LIST
            return NotificationManager.Policy(categories, any, any, fx)
        }
        return NotificationManager.Policy(categories, any, any)
    }
}
