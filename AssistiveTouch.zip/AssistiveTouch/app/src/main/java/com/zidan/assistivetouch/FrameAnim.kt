package com.zidan.assistivetouch

import android.view.Choreographer
import android.view.animation.Interpolator

/**
 * Animasi berbasis Choreographer. Waktu dihitung dari jam frame, bukan dari ValueAnimator, jadi
 * tetap berjalan walau skala animasi sistem dimatikan atau mode hemat daya aktif. Satu garis waktu
 * mengatur banyak properti sekaligus lewat [seg]. Bila [instant] true, langsung loncat ke keadaan akhir.
 */
class FrameAnim(
    private val durationMs: Long,
    private val instant: Boolean = false,
    private val onEnd: (() -> Unit)? = null,
    private val onFrame: (t: Long) -> Unit
) : Choreographer.FrameCallback {

    private var startMs = -1L
    private var running = false

    fun start(): FrameAnim {
        if (instant) {
            onFrame(durationMs)
            onEnd?.invoke()
            return this
        }
        running = true
        startMs = -1L
        onFrame(0L)
        Choreographer.getInstance().postFrameCallback(this)
        return this
    }

    fun cancel() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val now = frameTimeNanos / 1_000_000L
        if (startMs < 0) startMs = now
        val t = now - startMs
        if (t >= durationMs) {
            running = false
            onFrame(durationMs)
            onEnd?.invoke()
            return
        }
        onFrame(t)
        Choreographer.getInstance().postFrameCallback(this)
    }

    companion object {
        /** Kemajuan 0..1 dari satu potongan garis waktu: mulai di [delay], lama [dur]. */
        fun seg(t: Long, delay: Long, dur: Long, i: Interpolator): Float =
            i.getInterpolation(((t - delay).toFloat() / dur).coerceIn(0f, 1f))
    }
}
