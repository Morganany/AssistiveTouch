package com.zidan.assistivetouch

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Layar pengaturan sederhana. Tidak ada library UI tambahan agar APK kecil. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var battery: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi(): ScrollView {
        val prefs = Prefs.get(this)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }

        column.addView(text(getString(R.string.app_name), 30f, Color.WHITE, bold = true))
        column.addView(text(getString(R.string.subtitle), 14f, MUTED).apply { setPadding(0, dp(6), 0, dp(24)) })

        status = text("", 15f, Color.WHITE).apply {
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(CARD, 18)
        }
        column.addView(status)

        val open = Button(this).apply {
            text = getString(R.string.btn_open_settings)
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 15f
            background = rounded(ACCENT, 16)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        column.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })

        battery = Button(this).apply {
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 15f
            background = rounded(Color.parseColor("#2A2A33"), 16)
            setOnClickListener { requestBackgroundAccess() }
        }
        column.addView(battery, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) })

        // Ukuran tombol: 40 sampai 80 dp
        val sizeLabel = text("", 14f, Color.WHITE).apply { setPadding(0, dp(28), 0, dp(4)) }
        val size = prefs.getInt(Prefs.SIZE, Prefs.DEFAULT_SIZE)
        sizeLabel.text = getString(R.string.size_label, size)
        column.addView(sizeLabel)
        column.addView(SeekBar(this).apply {
            max = 40
            progress = size - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                    sizeLabel.text = getString(R.string.size_label, value + 40)
                }
                override fun onStartTrackingTouch(bar: SeekBar) = Unit
                override fun onStopTrackingTouch(bar: SeekBar) {
                    prefs.edit().putInt(Prefs.SIZE, bar.progress + 40).apply()
                }
            })
        })

        // Transparansi saat diam: 30 sampai 100 persen
        val opacityLabel = text("", 14f, Color.WHITE).apply { setPadding(0, dp(20), 0, dp(4)) }
        val opacity = prefs.getInt(Prefs.OPACITY, Prefs.DEFAULT_OPACITY)
        opacityLabel.text = getString(R.string.opacity_label, opacity)
        column.addView(opacityLabel)
        column.addView(SeekBar(this).apply {
            max = 70
            progress = opacity - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                    opacityLabel.text = getString(R.string.opacity_label, value + 30)
                }
                override fun onStartTrackingTouch(bar: SeekBar) = Unit
                override fun onStopTrackingTouch(bar: SeekBar) {
                    prefs.edit().putInt(Prefs.OPACITY, bar.progress + 30).apply()
                }
            })
        })

        column.addView(Switch(this).apply {
            text = getString(R.string.haptic_label)
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = prefs.getBoolean(Prefs.HAPTIC, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.HAPTIC, checked).apply()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(24)
        })

        column.addView(text(getString(R.string.hint_restricted), 12f, MUTED).apply { setPadding(0, dp(28), 0, 0) })
        column.addView(text(getString(R.string.hint_background), 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) })

        return ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(column)
        }
    }

    private fun refreshStatus() {
        val on = isServiceEnabled()
        status.setText(if (on) R.string.status_on else R.string.status_off)
        val unrestricted = isIgnoringBatteryOptimizations()
        battery.setText(if (unrestricted) R.string.battery_ok else R.string.btn_battery)
        battery.alpha = if (unrestricted) 0.6f else 1f
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBackgroundAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || isIgnoringBatteryOptimizations()) return
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val component = ComponentName(this, TouchService::class.java)
        val full = component.flattenToString()
        val short = component.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private companion object {
        val BG = Color.parseColor("#0E0E12")
        val CARD = Color.parseColor("#1C1C22")
        val ACCENT = Color.parseColor("#0A84FF")
        val MUTED = Color.parseColor("#8E8E98")
    }
}
