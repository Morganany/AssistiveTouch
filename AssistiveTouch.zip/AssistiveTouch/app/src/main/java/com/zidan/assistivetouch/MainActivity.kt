package com.zidan.assistivetouch

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Layar pengaturan sederhana. Tidak ada library UI tambahan agar APK kecil. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var battery: Button
    private var dndButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi(): ScrollView {
        val prefs = Prefs.get(this)

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }

        column.addView(text(getString(R.string.app_name), 30f, Color.WHITE, bold = true))
        column.addView(text(getString(R.string.subtitle), 14f, MUTED).apply { setPadding(0, dp(6), 0, dp(24)) })

        status = text("", 15f, Color.WHITE).apply {
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(CARD, 18)
        }
        column.addView(status)

        val open = Button(this).apply {
            text = getString(R.string.btn_open_settings)
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 15f
            background = rounded(ACCENT, 16)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        column.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(14) })

        battery = Button(this).apply {
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 15f
            background = rounded(Color.parseColor("#2A2A33"), 16)
            setOnClickListener { requestBackgroundAccess() }
        }
        column.addView(battery, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) })

        // Ukuran tombol: 40 sampai 80 dp
        val sizeLabel = text("", 14f, Color.WHITE).apply { setPadding(0, dp(28), 0, dp(4)) }
        val size = prefs.getInt(Prefs.SIZE, Prefs.DEFAULT_SIZE)
        sizeLabel.text = getString(R.string.size_label, size)
        column.addView(sizeLabel)
        column.addView(SeekBar(this).apply {
            max = 40
            progress = size - 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                    sizeLabel.text = getString(R.string.size_label, value + 40)
                }
                override fun onStartTrackingTouch(bar: SeekBar) = Unit
                override fun onStopTrackingTouch(bar: SeekBar) {
                    prefs.edit().putInt(Prefs.SIZE, bar.progress + 40).apply()
                }
            })
        })

        // Transparansi saat diam: 30 sampai 100 persen
        val opacityLabel = text("", 14f, Color.WHITE).apply { setPadding(0, dp(20), 0, dp(4)) }
        val opacity = prefs.getInt(Prefs.OPACITY, Prefs.DEFAULT_OPACITY)
        opacityLabel.text = getString(R.string.opacity_label, opacity)
        column.addView(opacityLabel)
        column.addView(SeekBar(this).apply {
            max = 70
            progress = opacity - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) {
                    opacityLabel.text = getString(R.string.opacity_label, value + 30)
                }
                override fun onStartTrackingTouch(bar: SeekBar) = Unit
                override fun onStopTrackingTouch(bar: SeekBar) {
                    prefs.edit().putInt(Prefs.OPACITY, bar.progress + 30).apply()
                }
            })
        })

        column.addView(Switch(this).apply {
            text = getString(R.string.haptic_label)
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = prefs.getBoolean(Prefs.HAPTIC, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.HAPTIC, checked).apply()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(24)
        })

        column.addView(Switch(this).apply {
            text = getString(R.string.keep_alive_label)
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = prefs.getBoolean(Prefs.KEEP_ALIVE, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.KEEP_ALIVE, checked).apply()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(16)
        })
        column.addView(text(getString(R.string.keep_alive_hint), 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })

        addButtonSection(column, prefs)
        addRotateSection(column, prefs)
        addGameSection(column, prefs)

        column.addView(text(getString(R.string.hint_restricted), 12f, MUTED).apply { setPadding(0, dp(28), 0, 0) })
        column.addView(text(getString(R.string.hint_background), 12f, MUTED).apply { setPadding(0, dp(14), 0, 0) })

        return ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(column)
        }
    }

    // ------------------------------------------------------ atur tombol menu

    private fun sectionTitle(column: LinearLayout, title: Int, top: Int = 32) {
        column.addView(text(getString(title), 17f, Color.WHITE, bold = true).apply {
            setPadding(0, dp(top), 0, dp(6))
        })
    }

    private fun pickerButton(label: () -> String, onClick: (refresh: () -> Unit) -> Unit): Button {
        val b = Button(this)
        b.apply {
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 14f
            background = rounded(CARD, 16)
            text = label()
            setOnClickListener { onClick { b.text = label() } }
        }
        return b
    }

    private fun addButtonSection(column: LinearLayout, prefs: SharedPreferences) {
        addSlotGrid(
            column, prefs, Prefs.SLOTS, Actions.DEFAULT,
            R.string.buttons_title, R.string.buttons_hint, sub = false
        )
        addSlotGrid(
            column, prefs, Prefs.SLOTS_SUB, Actions.DEFAULT_SUB,
            R.string.buttons_sub_title, R.string.buttons_sub_hint, sub = true
        )
    }

    /** Grid 3x3 pengatur slot. Pada folder (sub), slot tengah selalu Kembali dan tidak bisa diubah. */
    private fun addSlotGrid(
        column: LinearLayout,
        prefs: SharedPreferences,
        key: String,
        default: List<String>,
        title: Int,
        hint: Int,
        sub: Boolean
    ) {
        sectionTitle(column, title)
        column.addView(text(getString(hint), 12f, MUTED).apply { setPadding(0, 0, 0, dp(10)) })

        val slots = Actions.load(prefs, key, default)
        val cells = ArrayList<TextView>()
        fun bindAll() {
            for (i in cells.indices) {
                if (sub && i == Actions.CENTER) {
                    cells[i].text = getString(R.string.label_back)
                    cells[i].setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_back, 0, 0)
                    cells[i].alpha = 0.5f
                    continue
                }
                val def = Actions.find(slots[i])
                cells[i].text = getString(def.label)
                cells[i].setCompoundDrawablesWithIntrinsicBounds(0, def.icon, 0, 0)
                cells[i].alpha = if (def.id == Actions.NONE) 0.5f else 1f
            }
        }

        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 3) {
                val index = r * 3 + c
                val cell = TextView(this).apply {
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    maxLines = 1
                    compoundDrawablePadding = dp(4)
                    setPadding(dp(4), dp(12), dp(4), dp(10))
                    background = rounded(CARD, 16)
                    if (!(sub && index == Actions.CENTER)) {
                        setOnClickListener { chooseAction(prefs, key, slots, index, sub) { bindAll() } }
                    }
                }
                cells.add(cell)
                row.addView(
                    cell,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                )
            }
            column.addView(row)
        }
        bindAll()

        column.addView(Button(this).apply {
            text = getString(R.string.btn_reset_buttons)
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 14f
            background = rounded(Color.parseColor("#2A2A33"), 16)
            setOnClickListener {
                Actions.reset(prefs, key)
                slots.clear()
                slots.addAll(Actions.load(prefs, key, default))
                bindAll()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
    }

    /** Memilih fungsi untuk satu slot. Jika fungsi itu sudah ada di slot lain, keduanya bertukar. */
    private fun chooseAction(
        prefs: SharedPreferences,
        key: String,
        slots: MutableList<String>,
        index: Int,
        sub: Boolean,
        changed: () -> Unit
    ) {
        // Folder tidak boleh berisi folder lagi.
        val choices = Actions.ALL.filter { !(sub && it.id == Actions.FOLDER) }
        val labels = choices.map { getString(it.label) }.toTypedArray()
        val current = choices.indexOfFirst { it.id == slots[index] }
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_choose_action)
            .setSingleChoiceItems(labels, current) { dialog, which ->
                val id = choices[which].id
                val other = slots.indexOf(id)
                val swappable = other >= 0 && other != index && !(sub && other == Actions.CENTER)
                if (id != Actions.NONE && swappable) slots[other] = slots[index]
                slots[index] = id
                Actions.save(prefs, slots, key)
                changed()
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ------------------------------------------------------------ kunci rotasi

    private fun rotateModeName(mode: Int): String = getString(
        when (mode) {
            Prefs.ROTATE_PORTRAIT -> R.string.rotate_mode_portrait
            Prefs.ROTATE_LANDSCAPE -> R.string.rotate_mode_landscape
            else -> R.string.rotate_mode_current
        }
    )

    private fun addRotateSection(column: LinearLayout, prefs: SharedPreferences) {
        sectionTitle(column, R.string.rotate_title)
        val button = pickerButton(
            { getString(R.string.rotate_mode_label, rotateModeName(prefs.getInt(Prefs.ROTATE_MODE, Prefs.ROTATE_CURRENT))) }
        ) { refresh ->
            val modes = intArrayOf(Prefs.ROTATE_CURRENT, Prefs.ROTATE_PORTRAIT, Prefs.ROTATE_LANDSCAPE)
            AlertDialog.Builder(this)
                .setTitle(R.string.rotate_title)
                .setSingleChoiceItems(
                    modes.map { rotateModeName(it) }.toTypedArray(),
                    modes.indexOf(prefs.getInt(Prefs.ROTATE_MODE, Prefs.ROTATE_CURRENT))
                ) { dialog, which ->
                    prefs.edit().putInt(Prefs.ROTATE_MODE, modes[which]).apply()
                    refresh()
                    dialog.dismiss()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
        column.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        column.addView(text(getString(R.string.rotate_hint), 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
    }

    // ------------------------------------------------------------ game booster

    private fun appLabel(pkg: String?): String {
        if (pkg == null) return getString(R.string.game_none)
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    @Suppress("DEPRECATION")
    private fun launchableApps(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    private fun addGameSection(column: LinearLayout, prefs: SharedPreferences) {
        sectionTitle(column, R.string.game_title)
        val button = pickerButton(
            { getString(R.string.game_label, appLabel(prefs.getString(Prefs.GAME_PKG, null))) }
        ) { refresh ->
            val apps = launchableApps()
            val names = (listOf(getString(R.string.game_none)) + apps.map { it.first }).toTypedArray()
            val saved = prefs.getString(Prefs.GAME_PKG, null)
            val current = if (saved == null) 0 else apps.indexOfFirst { it.second == saved } + 1
            AlertDialog.Builder(this)
                .setTitle(R.string.game_pick_title)
                .setSingleChoiceItems(names, current) { dialog, which ->
                    val editor = prefs.edit()
                    if (which == 0) editor.remove(Prefs.GAME_PKG) else editor.putString(Prefs.GAME_PKG, apps[which - 1].second)
                    editor.apply()
                    refresh()
                    dialog.dismiss()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
        column.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        column.addView(text(getString(R.string.game_hint), 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })

        column.addView(Switch(this).apply {
            text = getString(R.string.hide_notif_label)
            setTextColor(Color.WHITE)
            textSize = 14f
            isChecked = prefs.getBoolean(Prefs.HIDE_NOTIF, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(Prefs.HIDE_NOTIF, checked).apply()
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(18)
        })
        val dnd = Button(this).apply {
            setAllCaps(false)
            setTextColor(Color.WHITE)
            textSize = 14f
            background = rounded(Color.parseColor("#2A2A33"), 16)
            setOnClickListener { openDndAccess() }
        }
        dndButton = dnd
        column.addView(dnd, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        column.addView(text(getString(R.string.hide_notif_hint), 12f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
    }

    private fun refreshStatus() {
        val on = isServiceEnabled()
        status.setText(if (on) R.string.status_on else R.string.status_off)
        val unrestricted = isIgnoringBatteryOptimizations()
        battery.setText(if (unrestricted) R.string.battery_ok else R.string.btn_battery)
        battery.alpha = if (unrestricted) 0.6f else 1f
        dndButton?.let { b ->
            val ok = QuietMode.hasAccess(this)
            b.setText(if (ok) R.string.dnd_ok else R.string.btn_dnd_access)
            b.alpha = if (ok) 0.6f else 1f
        }
    }

    private fun openDndAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || QuietMode.hasAccess(this)) return
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        } catch (e: Exception) {
            // layar pengaturan tidak tersedia di perangkat ini
        }
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBackgroundAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || isIgnoringBatteryOptimizations()) return
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val component = ComponentName(this, TouchService::class.java)
        val full = component.flattenToString()
        val short = component.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.START
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private companion object {
        val BG = Color.parseColor("#0E0E12")
        val CARD = Color.parseColor("#1C1C22")
        val ACCENT = Color.parseColor("#0A84FF")
        val MUTED = Color.parseColor("#8E8E98")
    }
}
