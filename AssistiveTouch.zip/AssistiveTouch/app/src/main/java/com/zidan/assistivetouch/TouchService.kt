package com.zidan.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Service aksesibilitas yang menampilkan tombol melayang dan menu kaca.
 *
 * Desain hemat memori:
 *  - Tidak ada foreground service, timer berulang, polling, atau receiver.
 *  - Tidak mendengarkan event aplikasi lain (accessibilityEventTypes kosong).
 *  - Menu dibuat saat dibuka dan dibuang penuh saat ditutup.
 *  - Semua ikon berupa vektor, semua gambar dirender dengan Canvas.
 */
class TouchService : AccessibilityService() {

    private companion object {
        const val CHANNEL_ID = "keep_alive"
        const val NOTIFICATION_ID = 1
        const val PANEL_DP = 290
    }

    private class Item(
        val label: Int,
        val icon: Int,
        val enabled: Boolean = true,
        val delay: Long = 150L,
        val keepOpen: Boolean = false,
        val action: () -> Unit
    )

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var button: FloatingButton? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var menu: FrameLayout? = null
    private var opening = false
    private var snapAnimator: ValueAnimator? = null
    private val ease = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    /** Untuk memudar: kurva simetris supaya tidak terasa tersentak seperti ease yang menukik di awal. */
    private val fade = PathInterpolator(0.4f, 0f, 0.2f, 1f)
    private var rotateView: View? = null
    private var mainPanel: LinearLayout? = null
    private var leaving: View? = null
    /** Menu yang sedang memudar keluar. Selama ada, menu baru belum boleh dibuka. */
    private var closing: View? = null
    private var alive = false
    private var anim: FrameAnim? = null
    private var menuAnim: FrameAnim? = null
    private val overshootSoft = OvershootInterpolator(0.9f)
    private val overshootTile = OvershootInterpolator(1.2f)
    private val overshootPanel = OvershootInterpolator(0.7f)
    private var subPanel: LinearLayout? = null
    private var panelColors = intArrayOf(0xCC34343C.toInt(), 0xCC1E1E24.toInt())
    private var boosting = false

    private val fadeTask = Runnable {
        button?.animate()?.alpha(idleAlpha())?.setDuration(350)?.start()
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.SIZE || key == Prefs.OPACITY) applyPrefs()
        if (key == Prefs.KEEP_ALIVE) updateKeepAlive()
        if (key == Prefs.ROTATE_MODE) applyRotation()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs.get(this)
        alive = true
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        QuietMode.exit(this)
        showButton()
        updateKeepAlive()
        applyRotation()
    }

    // ---------------------------------------------------------------- keep alive

    /**
     * Foreground service dengan notifikasi prioritas minimum: tanpa suara, tanpa popup,
     * tanpa ikon di status bar. Membuat proses jauh lebih sulit dimatikan oleh
     * "Tutup semua" dan penghemat RAM pabrikan. Android 13 ke atas: notifikasinya
     * tersembunyi karena izin notifikasi tidak diminta, layanan tetap berjalan.
     */
    private fun updateKeepAlive() {
        if (!::prefs.isInitialized) return
        if (prefs.getBoolean(Prefs.KEEP_ALIVE, true)) startKeepAlive() else stopKeepAlive()
    }

    @Suppress("DEPRECATION")
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val builder: Notification.Builder
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN
                ).apply {
                    setShowBadge(false)
                    setSound(null, null)
                    enableVibration(false)
                }
                nm.createNotificationChannel(channel)
                builder = Notification.Builder(this, CHANNEL_ID)
            } else {
                builder = Notification.Builder(this).setPriority(Notification.PRIORITY_MIN)
            }
            val notification = builder
                .setSmallIcon(R.drawable.ic_home)
                .setContentTitle(getString(R.string.app_name))
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Jika sistem menolak, layanan tetap berjalan seperti biasa.
        }
    }

    @Suppress("DEPRECATION")
    private fun stopKeepAlive() {
        try {
            stopForeground(true)
        } catch (e: Exception) {
            // abaikan
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeMenu(false)
        val lp = buttonLp ?: return
        clampPosition(lp)
        snapToEdge(false)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        alive = false
        opening = false
        handler.removeCallbacksAndMessages(null)
        menuAnim?.cancel()
        anim?.cancel()
        closing?.let { removeView(it) }
        closing = null
        snapAnimator?.cancel()
        snapAnimator = null
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        closeMenu(false)
        hideButton()
        removeRotation()
        boosting = false
        QuietMode.exit(this)
        stopKeepAlive()
    }

    // ------------------------------------------------------------------- button

    private fun showButton() {
        hideButton()
        val size = buttonSizePx()
        val screen = screenSize()
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(Prefs.X, screen.x - size - dp(4))
            y = prefs.getInt(Prefs.Y, screen.y / 2)
        }
        clampPosition(lp)

        val view = FloatingButton(this).apply {
            contentDescription = getString(R.string.app_name)
            setOnClickListener {
                haptic(this)
                openMenu()
            }
            setOnTouchListener(dragListener(lp))
        }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            return
        }
        button = view
        buttonLp = lp
        snapToEdge(false)
        scheduleFade()
    }

    private fun hideButton() {
        button?.let { removeView(it) }
        button = null
        buttonLp = null
    }

    private fun dragListener(lp: WindowManager.LayoutParams) = object : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop = ViewConfiguration.get(this@TouchService).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    handler.removeCallbacks(fadeTask)
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    v.animate().cancel()
                    v.alpha = 1f
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clampPosition(lp)
                        updateButton()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    when {
                        dragging -> {
                            snapToEdge(true)
                            scheduleFade()
                        }
                        e.actionMasked == MotionEvent.ACTION_UP -> v.performClick()
                        else -> scheduleFade()
                    }
                }
            }
            return true
        }
    }

    private fun updateButton() {
        val view = button ?: return
        val lp = buttonLp ?: return
        if (!view.isAttachedToWindow) return
        try {
            wm.updateViewLayout(view, lp)
        } catch (e: Exception) {
            // jendela sudah dilepas
        }
    }

    private fun snapToEdge(animate: Boolean) {
        val lp = buttonLp ?: return
        val screen = screenSize()
        val margin = dp(4)
        val target = if (lp.x + lp.width / 2 < screen.x / 2) margin else screen.x - lp.width - margin

        snapAnimator?.cancel()
        if (!animate) {
            lp.x = target
            updateButton()
            savePosition()
            return
        }
        snapAnimator = ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                updateButton()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    savePosition()
                }
            })
            start()
        }
    }

    private fun clampPosition(lp: WindowManager.LayoutParams) {
        val screen = screenSize()
        val top = dp(24)
        val bottom = dp(48)
        lp.x = lp.x.coerceIn(0, maxOf(0, screen.x - lp.width))
        lp.y = lp.y.coerceIn(top, maxOf(top, screen.y - lp.height - bottom))
    }

    private fun savePosition() {
        val lp = buttonLp ?: return
        prefs.edit().putInt(Prefs.X, lp.x).putInt(Prefs.Y, lp.y).apply()
    }

    private fun applyPrefs() {
        val lp = buttonLp ?: return
        val size = buttonSizePx()
        lp.width = size
        lp.height = size
        clampPosition(lp)
        snapToEdge(false)
        button?.alpha = 1f
        scheduleFade()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeTask)
        handler.postDelayed(fadeTask, 2500L)
    }

    private fun idleAlpha(): Float =
        prefs.getInt(Prefs.OPACITY, Prefs.DEFAULT_OPACITY) / 100f

    private fun buttonSizePx(): Int = dp(prefs.getInt(Prefs.SIZE, Prefs.DEFAULT_SIZE))

    // --------------------------------------------------------------------- menu

    private fun openMenu() {
        if (menu != null || opening || closing != null) return
        opening = true
        handler.removeCallbacks(fadeTask)
        button?.alpha = 1f

        // Android 11 ke atas: ambil tangkapan layar di memori, buramkan, lalu jadikan latar menu.
        // Tidak disimpan ke penyimpanan dan tidak dikirim ke mana pun.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    mainExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                            // Salin dan buramkan di thread terpisah supaya thread utama tetap lancar
                            // dan animasi pembuka menu tidak tersendat.
                            Thread {
                                val backdrop = try {
                                    buildBackdrop(screenshot)
                                } catch (e: Throwable) {
                                    null
                                }
                                handler.post { showMenu(backdrop) }
                            }.start()
                        }

                        override fun onFailure(errorCode: Int) {
                            showMenu(null)
                        }
                    }
                )
                return
            } catch (e: Exception) {
                // lanjut ke tampilan cadangan
            }
        }
        showMenu(null)
    }

    private fun showMenu(backdrop: Bitmap?) {
        opening = false
        if (!alive || menu != null) {
            backdrop?.recycle()
            return
        }

        val blur = backdrop == null &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && wm.isCrossWindowBlurEnabled

        val root = FrameLayout(this)
        root.setOnClickListener { closeMenu() }

        if (backdrop != null) {
            // Saturasi dan redaman sudah dibakar ke bitmap (lihat blurSmall), jadi satu lapisan saja.
            root.addView(
                ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_XY
                    setImageBitmap(backdrop)
                },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }

        panelColors = when {
            backdrop != null -> intArrayOf(0x4DFFFFFF, 0x38404050)
            blur -> intArrayOf(0x55646470, 0x33303038)
            else -> intArrayOf(0xCC34343C.toInt(), 0xCC1E1E24.toInt())
        }
        val panel = makePanel(buildItems())
        mainPanel = panel
        root.addView(panel, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = if (blur) 0.18f else 0.45f
        if (backdrop != null) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_DIM_BEHIND.inv()
        }
        if (blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            @Suppress("DEPRECATION")
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 70
        }

        root.alpha = 0f
        panel.scaleX = 0.88f
        panel.scaleY = 0.88f
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        menu = root
        menuAnim?.cancel()
        menuAnim = runAnim(360) { t ->
            root.alpha = FrameAnim.seg(t, 0, 220, fade)
            val k = 0.88f + 0.12f * FrameAnim.seg(t, 0, 360, overshootPanel)
            panel.scaleX = k
            panel.scaleY = k
        }
    }

    /** Tangkapan layar -> kecilkan 1/8 -> box blur dua kali. Kecil, cepat, dan hemat memori. */
    private fun buildBackdrop(result: AccessibilityService.ScreenshotResult): Bitmap? {
        val hardware = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
        val full = hardware?.copy(Bitmap.Config.ARGB_8888, false)
        hardware?.recycle()
        result.hardwareBuffer.close()
        if (full == null) return null

        val small = Bitmap.createScaledBitmap(
            full, maxOf(1, full.width / 8), maxOf(1, full.height / 8), true
        )
        if (small !== full) full.recycle()
        return blurSmall(small, 3)
    }

    private fun blurSmall(src: Bitmap, radius: Int): Bitmap {
        val w = src.width
        val h = src.height
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        repeat(2) {
            boxPass(a, b, w, h, radius, true)
            boxPass(b, a, w, h, radius, false)
        }
        val blurred = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        blurred.setPixels(a, 0, w, 0, 0, w, h)
        src.recycle()

        // Bakar saturasi dan redaman gelap sekali di sini (bitmap kecil), bukan tiap frame saat animasi.
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.35f) })
        }
        canvas.drawBitmap(blurred, 0f, 0f, paint)
        canvas.drawColor(0x26000000)
        blurred.recycle()
        return out
    }

    private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val n = 2 * r + 1
        for (line in 0 until lines) {
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (k in -r..r) {
                val i = k.coerceIn(0, len - 1)
                val p = src[if (horizontal) line * w + i else i * w + line]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until len) {
                dst[if (horizontal) line * w + i else i * w + line] =
                    ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val add = src[
                    if (horizontal) line * w + minOf(i + r + 1, len - 1)
                    else minOf(i + r + 1, len - 1) * w + line
                ]
                val sub = src[
                    if (horizontal) line * w + maxOf(i - r, 0)
                    else maxOf(i - r, 0) * w + line
                ]
                sa += (add ushr 24) - (sub ushr 24)
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }

    /** Satu panel kaca 3x3. Dipakai untuk menu utama dan folder Lainnya. */
    private fun makePanel(items: List<Item>, withBackground: Boolean = true): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            if (withBackground) {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, panelColors).apply {
                    cornerRadius = dp(34).toFloat()
                    setStroke(dp(1), 0x59FFFFFF)
                }
            }
        }
        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 3) {
                row.addView(
                    createTile(items[r * 3 + c]),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                )
            }
            panel.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        return panel
    }

    /** Semua tombol (view tile) di sebuah panel beserta alpha aslinya (tombol nonaktif lebih redup). */
    private fun tilesOf(panel: LinearLayout): List<Triple<View, Float, Int>> {
        val out = ArrayList<Triple<View, Float, Int>>()
        for (r in 0 until panel.childCount) {
            val row = panel.getChildAt(r) as? ViewGroup ?: continue
            for (c in 0 until row.childCount) {
                val tile = row.getChildAt(c)
                out.add(Triple(tile, tile.alpha, r + c))
            }
        }
        return out
    }

    /**
     * Folder Lainnya gaya iOS. Kartu kaca tetap satu dan tidak pernah memudar, jadi tidak ada
     * kedipan dan tidak ada kartu tembus. Yang berganti hanya isinya: tombol menu utama mengecil
     * dan memudar, tombol folder masuk berurutan dari kiri atas dengan sedikit pantulan. Kartu
     * berdenyut halus. Tidak ada kartu tambahan di belakang atau di atas panel.
     */
    private fun openSub() {
        val root = menu ?: return
        val card = mainPanel ?: return
        if (subPanel != null) return
        anim?.cancel()
        leaving?.let { root.removeView(it) }
        leaving = null

        val sub = makePanel(buildSubItems(), withBackground = false)
        root.addView(sub, FrameLayout.LayoutParams(dp(PANEL_DP), dp(PANEL_DP), Gravity.CENTER))
        subPanel = sub

        val outTiles = tilesOf(card)
        val inTiles = tilesOf(sub)
        for ((tile, _, _) in inTiles) {
            tile.alpha = 0f
            tile.scaleX = 0.8f
            tile.scaleY = 0.8f
        }

        anim = runAnim(560) { t ->
            // Denyut kartu: mengecil sedikit lalu kembali.
            val pulse = 1f - 0.04f * sin(PI.toFloat() * (t / 440f).coerceIn(0f, 1f))
            card.scaleX = pulse
            card.scaleY = pulse

            for ((tile, alpha0, d) in outTiles) {
                val e = FrameAnim.seg(t, 20L * d, 180, fade)
                tile.alpha = alpha0 * (1f - e)
                val k = 1f - 0.15f * e
                tile.scaleX = k
                tile.scaleY = k
            }
            for ((tile, target, d) in inTiles) {
                val delay = 110L + 35L * d
                tile.alpha = target * FrameAnim.seg(t, delay, 220, fade)
                val k = 0.8f + 0.2f * FrameAnim.seg(t, delay, 320, overshootTile)
                tile.scaleX = k
                tile.scaleY = k
            }
        }
    }

    private fun closeSub() {
        val sub = subPanel ?: return
        val card = mainPanel
        subPanel = null
        leaving = sub
        anim?.cancel()

        // Mulai dari keadaan saat ini supaya tetap mulus bila Kembali ditekan di tengah animasi.
        val outTiles = tilesOf(sub).map { (tile, _, d) -> Triple(tile, tile.alpha, d) }
        val inTiles = if (card != null) tilesOf(card) else emptyList()
        val inStart = inTiles.map { it.first.alpha }
        // Alpha asli tombol utama: nonaktif 0.35, lainnya 1. Dibaca dari item, bukan dari keadaan saat ini.
        val targets = buildItems().map { if (it.enabled) 1f else 0.35f }

        anim = runAnim(480, onEnd = {
            menu?.removeView(sub)
            if (leaving === sub) leaving = null
        }) { t ->
            val pulse = 1f - 0.04f * sin(PI.toFloat() * (t / 400f).coerceIn(0f, 1f))
            card?.scaleX = pulse
            card?.scaleY = pulse

            for ((tile, alpha0, d) in outTiles) {
                val e = FrameAnim.seg(t, 15L * d, 150, fade)
                tile.alpha = alpha0 * (1f - e)
                val k = 1f - 0.2f * e
                tile.scaleX = k
                tile.scaleY = k
            }
            for ((i, entry) in inTiles.withIndex()) {
                val tile = entry.first
                val delay = 90L + 30L * entry.third
                val a = FrameAnim.seg(t, delay, 220, fade)
                val from = inStart[i]
                tile.alpha = from + ((targets.getOrElse(i) { 1f }) - from) * a
                val k = 0.85f + 0.15f * FrameAnim.seg(t, delay, 320, overshootTile)
                tile.scaleX = k
                tile.scaleY = k
            }
        }
    }

    /** Isi folder: slot tengah selalu Kembali, folder di dalam folder tidak diizinkan. */
    private fun buildSubItems(): List<Item> =
        Actions.load(prefs, Prefs.SLOTS_SUB, Actions.DEFAULT_SUB).mapIndexed { i, id ->
            when {
                i == Actions.CENTER ->
                    Item(R.string.label_back, R.drawable.ic_back, keepOpen = true) { closeSub() }
                id == Actions.FOLDER -> itemFor(Actions.NONE)
                else -> itemFor(id)
            }
        }

    private fun closeMenu(animate: Boolean = true) {
        val view = menu ?: return
        menu = null
        mainPanel = null
        subPanel = null
        leaving = null
        menuAnim?.cancel()
        anim?.cancel()
        if (animate && prefs.getBoolean(Prefs.ANIM, true)) {
            // Lapisan hardware dibuat sekali sebelum memudar. Tanpa ini, frame pertama memudar harus
            // membangun lapisan sebesar layar penuh dan terlihat sebagai kedipan.
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            closing = view
            val a0 = view.alpha
            menuAnim = runAnim(200, onEnd = {
                if (closing === view) closing = null
                removeView(view)
            }) { t ->
                view.alpha = a0 * (1f - FrameAnim.seg(t, 0, 200, fade))
            }
        } else {
            removeView(view)
        }
        scheduleFade()
    }

    /** Animasi menu memakai FrameAnim; pengguna bisa mematikannya di pengaturan (Prefs.ANIM). */
    private fun runAnim(duration: Long, onEnd: (() -> Unit)? = null, onFrame: (Long) -> Unit): FrameAnim =
        FrameAnim(duration, !prefs.getBoolean(Prefs.ANIM, true), onEnd, onFrame).start()

    /** Isi menu mengikuti urutan slot yang diatur pengguna (Prefs.SLOTS). */
    private fun buildItems(): List<Item> = Actions.load(prefs).map { itemFor(it) }

    private fun itemFor(id: String): Item {
        val def = Actions.find(id)
        val api28 = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        return when (id) {
            "notifications" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            }
            "control" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            }
            "back" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            "lock" -> Item(def.label, def.icon, enabled = api28) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                }
            }
            "home" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            "recents" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
            }
            "screenshot" -> Item(def.label, def.icon, enabled = api28, delay = 380L) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    button?.visibility = View.INVISIBLE
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                    handler.postDelayed({ button?.visibility = View.VISIBLE }, 1500L)
                }
            }
            "volume" -> Item(def.label, def.icon) {
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_SAME,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            "power" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            }
            "rotate" -> Item(
                if (rotateLocked()) R.string.label_rotate_locked else def.label, def.icon
            ) { toggleRotation() }
            "clean" -> Item(def.label, def.icon) {
                cleanRam { count, freed, avail -> toast(cleanMessage(count, freed, avail)) }
            }
            "boost" -> Item(
                if (boosting) R.string.label_boost_on else def.label, def.icon
            ) { toggleBoost() }
            Actions.FOLDER -> Item(def.label, def.icon, keepOpen = true) { openSub() }
            else -> Item(R.string.label_none, def.icon, enabled = false) {}
        }
    }

    // ------------------------------------------------------------ pembersih RAM

    /**
     * Menghentikan proses latar belakang aplikasi yang punya ikon peluncur (bukan aplikasi sistem)
     * dengan ActivityManager.killBackgroundProcesses. Tanpa root, jadi hanya proses di latar
     * belakang yang dihentikan: aplikasi yang sedang tampil (misalnya game) tidak tersentuh, dan
     * aplikasi dengan notifikasi foreground (pemutar musik, navigasi) umumnya bertahan.
     * Sekali jalan, tanpa timer berulang.
     */
    private fun cleanRam(onDone: (count: Int, freedMb: Int, availMb: Int) -> Unit) {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = availableMb(am)
        val skip = protectedPackages()
        // Mendata ratusan aplikasi dan mematikan prosesnya bisa memakan puluhan milidetik. Dikerjakan
        // di thread terpisah supaya animasi menu yang sedang menutup tidak tersendat.
        Thread {
            val count = killBackground(am, skip)
            // Beri waktu sistem melepas memori sebelum diukur ulang.
            handler.postDelayed({
                val after = availableMb(am)
                onDone(count, maxOf(0L, after - before).toInt(), after.toInt())
            }, 700L)
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun killBackground(am: ActivityManager, skip: Set<String>): Int {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        var count = 0
        for (ri in packageManager.queryIntentActivities(launcher, 0)) {
            val info = ri.activityInfo?.applicationInfo ?: continue
            val pkg = info.packageName
            if (pkg in skip || !seen.add(pkg)) continue
            if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (info.flags and ApplicationInfo.FLAG_STOPPED != 0) continue
            try {
                am.killBackgroundProcesses(pkg)
                count++
            } catch (e: Exception) {
                // abaikan aplikasi yang menolak
            }
        }
        return count
    }

    /** Aplikasi ini sendiri, peluncur (home), keyboard aktif, dan game pilihan tidak ikut dihentikan. */
    @Suppress("DEPRECATION")
    private fun protectedPackages(): Set<String> {
        val skip = HashSet<String>()
        skip.add(packageName)
        prefs.getString(Prefs.GAME_PKG, null)?.let { skip.add(it) }
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { skip.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { skip.add(it) }
        return skip
    }

    private fun availableMb(am: ActivityManager): Long {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    private fun cleanMessage(count: Int, freedMb: Int, availMb: Int): String =
        if (freedMb > 0) getString(R.string.toast_clean_freed, count, freedMb, availMb)
        else getString(R.string.toast_clean_none, count, availMb)

    // -------------------------------------------------------------- game booster

    /**
     * Booster: bersihkan RAM, tahan layar tetap menyala selama sesi game, dan buka game pilihan
     * jika ada. Tidak bisa menaikkan CPU/GPU tanpa root. Ketuk lagi untuk mengakhiri sesi.
     */
    private fun toggleBoost() {
        if (boosting) {
            setBoost(false)
            QuietMode.exit(this)
            toast(getString(R.string.toast_boost_off))
            return
        }
        setBoost(true)
        var head = getString(R.string.toast_boost_on)
        if (prefs.getBoolean(Prefs.HIDE_NOTIF, true)) {
            val hidden = QuietMode.enter(this)
            head += "\n" + getString(if (hidden) R.string.toast_quiet_on else R.string.toast_quiet_need_access)
        }
        cleanRam { count, freed, avail ->
            toast(head + "\n" + cleanMessage(count, freed, avail))
            launchGame()
        }
    }

    private fun setBoost(on: Boolean) {
        boosting = on
        buttonLp?.let { lp ->
            lp.flags = if (on) lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            else lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
            updateButton()
        }
        button?.boosting = on
    }

    private fun launchGame() {
        val pkg = prefs.getString(Prefs.GAME_PKG, null) ?: return
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // sistem menolak membuka aplikasi dari latar belakang
        }
    }

    // ------------------------------------------------------------- kunci rotasi

    private fun rotateLocked(): Boolean = prefs.getBoolean(Prefs.ROTATE_LOCKED, false)

    private fun toggleRotation() {
        val on = !rotateLocked()
        prefs.edit().putBoolean(Prefs.ROTATE_LOCKED, on).apply()
        applyRotation()
        toast(getString(if (on) R.string.toast_rotate_on else R.string.toast_rotate_off))
    }

    /**
     * Mengunci orientasi layar lewat jendela overlay aksesibilitas berukuran 1 px yang membawa
     * screenOrientation. Tidak butuh izin WRITE_SETTINGS dan tidak menghalangi sentuhan.
     * Dilepas saat kunci dimatikan atau layanan berhenti.
     */
    private fun applyRotation() {
        if (!::wm.isInitialized || !::prefs.isInitialized) return
        removeRotation()
        if (!rotateLocked()) return
        val orientation = when (prefs.getInt(Prefs.ROTATE_MODE, Prefs.ROTATE_CURRENT)) {
            Prefs.ROTATE_PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            Prefs.ROTATE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
        }
        val lp = WindowManager.LayoutParams(
            1,
            1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            screenOrientation = orientation
        }
        val view = View(this)
        try {
            wm.addView(view, lp)
            rotateView = view
        } catch (e: Exception) {
            // jendela ditolak
        }
    }

    private fun removeRotation() {
        rotateView?.let { removeView(it) }
        rotateView = null
    }

    private fun createTile(item: Item): View {
        val radius = dp(20).toFloat()
        val normal = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x26FFFFFF)
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x55FFFFFF)
        }
        val label = getString(item.label)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), pressed)
                addState(intArrayOf(), normal)
            }
            alpha = if (item.enabled) 1f else 0.35f
            contentDescription = label
            if (item.enabled) {
                isClickable = true
                setOnClickListener {
                    haptic(this)
                    if (item.keepOpen) {
                        item.action()
                    } else {
                        closeMenu()
                        handler.postDelayed({ item.action() }, item.delay)
                    }
                }
            }
            addView(
                ImageView(context).apply { setImageResource(item.icon) },
                LinearLayout.LayoutParams(dp(30), dp(30))
            )
            addView(
                TextView(context).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    gravity = Gravity.CENTER
                    maxLines = 1
                    setPadding(dp(2), dp(6), dp(2), 0)
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun haptic(view: View) {
        if (prefs.getBoolean(Prefs.HAPTIC, true)) {
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun removeView(view: View) {
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // sudah dilepas
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun screenSize(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }
}
