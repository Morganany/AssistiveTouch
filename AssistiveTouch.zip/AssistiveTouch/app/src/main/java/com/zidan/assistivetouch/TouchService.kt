package com.zidan.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/**
 * Service aksesibilitas yang menampilkan tombol melayang dan menu kaca.
 *
 * Desain hemat memori:
 *  - Tidak ada foreground service, timer berulang, polling, atau receiver.
 *  - Tidak mendengarkan event aplikasi lain (accessibilityEventTypes kosong).
 *  - Menu dibuat saat dibuka dan dibuang penuh saat ditutup.
 *  - Semua ikon berupa vektor, semua gambar dirender dengan Canvas.
 */
class TouchService : AccessibilityService() {

    private class Item(
        val label: Int,
        val icon: Int,
        val enabled: Boolean = true,
        val delay: Long = 150L,
        val action: () -> Unit
    )

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var button: FloatingButton? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var menu: FrameLayout? = null
    private var snapAnimator: ValueAnimator? = null

    private val fadeTask = Runnable {
        button?.animate()?.alpha(idleAlpha())?.setDuration(350)?.start()
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.SIZE || key == Prefs.OPACITY) applyPrefs()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs.get(this)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        showButton()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeMenu(false)
        val lp = buttonLp ?: return
        clampPosition(lp)
        snapToEdge(false)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        handler.removeCallbacksAndMessages(null)
        snapAnimator?.cancel()
        snapAnimator = null
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        closeMenu(false)
        hideButton()
    }

    // ------------------------------------------------------------------- button

    private fun showButton() {
        hideButton()
        val size = buttonSizePx()
        val screen = screenSize()
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(Prefs.X, screen.x - size - dp(4))
            y = prefs.getInt(Prefs.Y, screen.y / 2)
        }
        clampPosition(lp)

        val view = FloatingButton(this).apply {
            contentDescription = getString(R.string.app_name)
            setOnClickListener {
                haptic(this)
                openMenu()
            }
            setOnTouchListener(dragListener(lp))
        }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            return
        }
        button = view
        buttonLp = lp
        snapToEdge(false)
        scheduleFade()
    }

    private fun hideButton() {
        button?.let { removeView(it) }
        button = null
        buttonLp = null
    }

    private fun dragListener(lp: WindowManager.LayoutParams) = object : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop = ViewConfiguration.get(this@TouchService).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    handler.removeCallbacks(fadeTask)
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    v.animate().cancel()
                    v.alpha = 1f
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clampPosition(lp)
                        updateButton()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    when {
                        dragging -> {
                            snapToEdge(true)
                            scheduleFade()
                        }
                        e.actionMasked == MotionEvent.ACTION_UP -> v.performClick()
                        else -> scheduleFade()
                    }
                }
            }
            return true
        }
    }

    private fun updateButton() {
        val view = button ?: return
        val lp = buttonLp ?: return
        if (!view.isAttachedToWindow) return
        try {
            wm.updateViewLayout(view, lp)
        } catch (e: Exception) {
            // jendela sudah dilepas
        }
    }

    private fun snapToEdge(animate: Boolean) {
        val lp = buttonLp ?: return
        val screen = screenSize()
        val margin = dp(4)
        val target = if (lp.x + lp.width / 2 < screen.x / 2) margin else screen.x - lp.width - margin

        snapAnimator?.cancel()
        if (!animate) {
            lp.x = target
            updateButton()
            savePosition()
            return
        }
        snapAnimator = ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                updateButton()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    savePosition()
                }
            })
            start()
        }
    }

    private fun clampPosition(lp: WindowManager.LayoutParams) {
        val screen = screenSize()
        val top = dp(24)
        val bottom = dp(48)
        lp.x = lp.x.coerceIn(0, maxOf(0, screen.x - lp.width))
        lp.y = lp.y.coerceIn(top, maxOf(top, screen.y - lp.height - bottom))
    }

    private fun savePosition() {
        val lp = buttonLp ?: return
        prefs.edit().putInt(Prefs.X, lp.x).putInt(Prefs.Y, lp.y).apply()
    }

    private fun applyPrefs() {
        val lp = buttonLp ?: return
        val size = buttonSizePx()
        lp.width = size
        lp.height = size
        clampPosition(lp)
        snapToEdge(false)
        button?.alpha = 1f
        scheduleFade()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeTask)
        handler.postDelayed(fadeTask, 2500L)
    }

    private fun idleAlpha(): Float =
        prefs.getInt(Prefs.OPACITY, Prefs.DEFAULT_OPACITY) / 100f

    private fun buttonSizePx(): Int = dp(prefs.getInt(Prefs.SIZE, Prefs.DEFAULT_SIZE))

    // --------------------------------------------------------------------- menu

    private fun openMenu() {
        if (menu != null) return
        handler.removeCallbacks(fadeTask)
        button?.alpha = 1f

        val blur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && wm.isCrossWindowBlurEnabled

        val root = FrameLayout(this)
        root.setOnClickListener { closeMenu() }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                if (blur) intArrayOf(0x55646470, 0x33303038)
                else intArrayOf(0xCC34343C.toInt(), 0xCC1E1E24.toInt())
            ).apply {
                cornerRadius = dp(34).toFloat()
                setStroke(dp(1), 0x59FFFFFF)
            }
        }

        val items = buildItems()
        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 3) {
                val tile = createTile(items[r * 3 + c])
                row.addView(
                    tile,
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                )
            }
            panel.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        root.addView(panel, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = if (blur) 0.18f else 0.45f
        if (blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            @Suppress("DEPRECATION")
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 70
        }

        root.alpha = 0f
        panel.scaleX = 0.88f
        panel.scaleY = 0.88f
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        menu = root
        root.animate().alpha(1f).setDuration(160).start()
        panel.animate().scaleX(1f).scaleY(1f).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeMenu(animate: Boolean = true) {
        val view = menu ?: return
        menu = null
        if (animate) {
            view.animate().alpha(0f).setDuration(120).withEndAction { removeView(view) }.start()
        } else {
            view.animate().cancel()
            removeView(view)
        }
        scheduleFade()
    }

    private fun buildItems(): List<Item> {
        val api28 = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        return listOf(
            Item(R.string.label_notifications, R.drawable.ic_notifications) {
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            },
            Item(R.string.label_control, R.drawable.ic_control) {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            },
            Item(R.string.label_back, R.drawable.ic_back) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            },
            Item(R.string.label_lock, R.drawable.ic_lock, enabled = api28) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                }
            },
            Item(R.string.label_home, R.drawable.ic_home) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            },
            Item(R.string.label_recents, R.drawable.ic_recents) {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
            },
            Item(R.string.label_screenshot, R.drawable.ic_screenshot, enabled = api28, delay = 380L) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    button?.visibility = View.INVISIBLE
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                    handler.postDelayed({ button?.visibility = View.VISIBLE }, 1500L)
                }
            },
            Item(R.string.label_volume, R.drawable.ic_volume) {
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_SAME,
                    AudioManager.FLAG_SHOW_UI
                )
            },
            Item(R.string.label_power, R.drawable.ic_power) {
                performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            }
        )
    }

    private fun createTile(item: Item): View {
        val radius = dp(20).toFloat()
        val normal = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x26FFFFFF)
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x55FFFFFF)
        }
        val label = getString(item.label)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), pressed)
                addState(intArrayOf(), normal)
            }
            alpha = if (item.enabled) 1f else 0.35f
            contentDescription = label
            if (item.enabled) {
                isClickable = true
                setOnClickListener {
                    haptic(this)
                    closeMenu()
                    handler.postDelayed({ item.action() }, item.delay)
                }
            }
            addView(
                ImageView(context).apply { setImageResource(item.icon) },
                LinearLayout.LayoutParams(dp(30), dp(30))
            )
            addView(
                TextView(context).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    gravity = Gravity.CENTER
                    maxLines = 1
                    setPadding(dp(2), dp(6), dp(2), 0)
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun haptic(view: View) {
        if (prefs.getBoolean(Prefs.HAPTIC, true)) {
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun removeView(view: View) {
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // sudah dilepas
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun screenSize(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }
}
