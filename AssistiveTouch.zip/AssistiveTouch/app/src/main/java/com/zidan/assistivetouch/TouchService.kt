package com.zidan.assistivetouch

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.hypot

/**
 * Service aksesibilitas yang menampilkan tombol melayang dan menu kaca.
 *
 * Desain hemat memori:
 *  - Tidak ada foreground service, timer berulang, polling, atau receiver.
 *  - Tidak mendengarkan event aplikasi lain (accessibilityEventTypes kosong).
 *  - Menu dibuat saat dibuka dan dibuang penuh saat ditutup.
 *  - Semua ikon berupa vektor, semua gambar dirender dengan Canvas.
 */
class TouchService : AccessibilityService() {

    private companion object {
        const val CHANNEL_ID = "keep_alive"
        const val NOTIFICATION_ID = 1
    }

    private class Item(
        val label: Int,
        val icon: Int,
        val enabled: Boolean = true,
        val delay: Long = 150L,
        val keepOpen: Boolean = false,
        val action: () -> Unit
    )

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var button: FloatingButton? = null
    private var buttonLp: WindowManager.LayoutParams? = null
    private var menu: FrameLayout? = null
    private var opening = false
    private var snapAnimator: ValueAnimator? = null
    private var rotateView: View? = null
    private var mainPanel: LinearLayout? = null
    private var subPanel: LinearLayout? = null
    private var panelColors = intArrayOf(0xCC34343C.toInt(), 0xCC1E1E24.toInt())
    private var boosting = false

    private val fadeTask = Runnable {
        button?.animate()?.alpha(idleAlpha())?.setDuration(350)?.start()
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.SIZE || key == Prefs.OPACITY) applyPrefs()
        if (key == Prefs.KEEP_ALIVE) updateKeepAlive()
        if (key == Prefs.ROTATE_MODE) applyRotation()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs.get(this)
        prefs.registerOnSharedPreferenceChangeListener(prefsListener)
        QuietMode.exit(this)
        showButton()
        updateKeepAlive()
        applyRotation()
    }

    // ---------------------------------------------------------------- keep alive

    /**
     * Foreground service dengan notifikasi prioritas minimum: tanpa suara, tanpa popup,
     * tanpa ikon di status bar. Membuat proses jauh lebih sulit dimatikan oleh
     * "Tutup semua" dan penghemat RAM pabrikan. Android 13 ke atas: notifikasinya
     * tersembunyi karena izin notifikasi tidak diminta, layanan tetap berjalan.
     */
    private fun updateKeepAlive() {
        if (!::prefs.isInitialized) return
        if (prefs.getBoolean(Prefs.KEEP_ALIVE, true)) startKeepAlive() else stopKeepAlive()
    }

    @Suppress("DEPRECATION")
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val builder: Notification.Builder
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_MIN
                ).apply {
                    setShowBadge(false)
                    setSound(null, null)
                    enableVibration(false)
                }
                nm.createNotificationChannel(channel)
                builder = Notification.Builder(this, CHANNEL_ID)
            } else {
                builder = Notification.Builder(this).setPriority(Notification.PRIORITY_MIN)
            }
            val notification = builder
                .setSmallIcon(R.drawable.ic_home)
                .setContentTitle(getString(R.string.app_name))
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            // Jika sistem menolak, layanan tetap berjalan seperti biasa.
        }
    }

    @Suppress("DEPRECATION")
    private fun stopKeepAlive() {
        try {
            stopForeground(true)
        } catch (e: Exception) {
            // abaikan
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeMenu(false)
        val lp = buttonLp ?: return
        clampPosition(lp)
        snapToEdge(false)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        handler.removeCallbacksAndMessages(null)
        snapAnimator?.cancel()
        snapAnimator = null
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        closeMenu(false)
        hideButton()
        removeRotation()
        boosting = false
        QuietMode.exit(this)
        stopKeepAlive()
    }

    // ------------------------------------------------------------------- button

    private fun showButton() {
        hideButton()
        val size = buttonSizePx()
        val screen = screenSize()
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt(Prefs.X, screen.x - size - dp(4))
            y = prefs.getInt(Prefs.Y, screen.y / 2)
        }
        clampPosition(lp)

        val view = FloatingButton(this).apply {
            contentDescription = getString(R.string.app_name)
            setOnClickListener {
                haptic(this)
                openMenu()
            }
            setOnTouchListener(dragListener(lp))
        }

        try {
            wm.addView(view, lp)
        } catch (e: Exception) {
            return
        }
        button = view
        buttonLp = lp
        snapToEdge(false)
        scheduleFade()
    }

    private fun hideButton() {
        button?.let { removeView(it) }
        button = null
        buttonLp = null
    }

    private fun dragListener(lp: WindowManager.LayoutParams) = object : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var dragging = false
        private val slop = ViewConfiguration.get(this@TouchService).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    handler.removeCallbacks(fadeTask)
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    dragging = false
                    v.animate().cancel()
                    v.alpha = 1f
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clampPosition(lp)
                        updateButton()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    when {
                        dragging -> {
                            snapToEdge(true)
                            scheduleFade()
                        }
                        e.actionMasked == MotionEvent.ACTION_UP -> v.performClick()
                        else -> scheduleFade()
                    }
                }
            }
            return true
        }
    }

    private fun updateButton() {
        val view = button ?: return
        val lp = buttonLp ?: return
        if (!view.isAttachedToWindow) return
        try {
            wm.updateViewLayout(view, lp)
        } catch (e: Exception) {
            // jendela sudah dilepas
        }
    }

    private fun snapToEdge(animate: Boolean) {
        val lp = buttonLp ?: return
        val screen = screenSize()
        val margin = dp(4)
        val target = if (lp.x + lp.width / 2 < screen.x / 2) margin else screen.x - lp.width - margin

        snapAnimator?.cancel()
        if (!animate) {
            lp.x = target
            updateButton()
            savePosition()
            return
        }
        snapAnimator = ValueAnimator.ofInt(lp.x, target).apply {
            duration = 220
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                updateButton()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    savePosition()
                }
            })
            start()
        }
    }

    private fun clampPosition(lp: WindowManager.LayoutParams) {
        val screen = screenSize()
        val top = dp(24)
        val bottom = dp(48)
        lp.x = lp.x.coerceIn(0, maxOf(0, screen.x - lp.width))
        lp.y = lp.y.coerceIn(top, maxOf(top, screen.y - lp.height - bottom))
    }

    private fun savePosition() {
        val lp = buttonLp ?: return
        prefs.edit().putInt(Prefs.X, lp.x).putInt(Prefs.Y, lp.y).apply()
    }

    private fun applyPrefs() {
        val lp = buttonLp ?: return
        val size = buttonSizePx()
        lp.width = size
        lp.height = size
        clampPosition(lp)
        snapToEdge(false)
        button?.alpha = 1f
        scheduleFade()
    }

    private fun scheduleFade() {
        handler.removeCallbacks(fadeTask)
        handler.postDelayed(fadeTask, 2500L)
    }

    private fun idleAlpha(): Float =
        prefs.getInt(Prefs.OPACITY, Prefs.DEFAULT_OPACITY) / 100f

    private fun buttonSizePx(): Int = dp(prefs.getInt(Prefs.SIZE, Prefs.DEFAULT_SIZE))

    // --------------------------------------------------------------------- menu

    private fun openMenu() {
        if (menu != null || opening) return
        opening = true
        handler.removeCallbacks(fadeTask)
        button?.alpha = 1f

        // Android 11 ke atas: ambil tangkapan layar di memori, buramkan, lalu jadikan latar menu.
        // Tidak disimpan ke penyimpanan dan tidak dikirim ke mana pun.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    mainExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                            val backdrop = try {
                                buildBackdrop(screenshot)
                            } catch (e: Throwable) {
                                null
                            }
                            showMenu(backdrop)
                        }

                        override fun onFailure(errorCode: Int) {
                            showMenu(null)
                        }
                    }
                )
                return
            } catch (e: Exception) {
                // lanjut ke tampilan cadangan
            }
        }
        showMenu(null)
    }

    private fun showMenu(backdrop: Bitmap?) {
        opening = false
        if (menu != null) return

        val blur = backdrop == null &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && wm.isCrossWindowBlurEnabled

        val root = FrameLayout(this)
        root.setOnClickListener { closeMenu() }

        if (backdrop != null) {
            root.addView(
                ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_XY
                    setImageBitmap(backdrop)
                    colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.35f) })
                },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            root.addView(
                View(this).apply { setBackgroundColor(0x26000000) },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }

        panelColors = when {
            backdrop != null -> intArrayOf(0x4DFFFFFF, 0x38404050)
            blur -> intArrayOf(0x55646470, 0x33303038)
            else -> intArrayOf(0xCC34343C.toInt(), 0xCC1E1E24.toInt())
        }
        val panel = makePanel(buildItems())
        mainPanel = panel
        root.addView(panel, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT
        )
        lp.dimAmount = if (blur) 0.18f else 0.45f
        if (backdrop != null) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_DIM_BEHIND.inv()
        }
        if (blur && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            @Suppress("DEPRECATION")
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 70
        }

        root.alpha = 0f
        panel.scaleX = 0.88f
        panel.scaleY = 0.88f
        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        menu = root
        root.animate().alpha(1f).setDuration(160).start()
        panel.animate().scaleX(1f).scaleY(1f).setDuration(200)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    /** Tangkapan layar -> kecilkan 1/8 -> box blur dua kali. Kecil, cepat, dan hemat memori. */
    private fun buildBackdrop(result: AccessibilityService.ScreenshotResult): Bitmap? {
        val hardware = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
        val full = hardware?.copy(Bitmap.Config.ARGB_8888, false)
        hardware?.recycle()
        result.hardwareBuffer.close()
        if (full == null) return null

        val small = Bitmap.createScaledBitmap(
            full, maxOf(1, full.width / 8), maxOf(1, full.height / 8), true
        )
        if (small !== full) full.recycle()
        return blurSmall(small, 3)
    }

    private fun blurSmall(src: Bitmap, radius: Int): Bitmap {
        val w = src.width
        val h = src.height
        var a = IntArray(w * h)
        var b = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        repeat(2) {
            boxPass(a, b, w, h, radius, true)
            boxPass(b, a, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        src.recycle()
        return out
    }

    private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val n = 2 * r + 1
        for (line in 0 until lines) {
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (k in -r..r) {
                val i = k.coerceIn(0, len - 1)
                val p = src[if (horizontal) line * w + i else i * w + line]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until len) {
                dst[if (horizontal) line * w + i else i * w + line] =
                    ((sa / n) shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                val add = src[
                    if (horizontal) line * w + minOf(i + r + 1, len - 1)
                    else minOf(i + r + 1, len - 1) * w + line
                ]
                val sub = src[
                    if (horizontal) line * w + maxOf(i - r, 0)
                    else maxOf(i - r, 0) * w + line
                ]
                sa += (add ushr 24) - (sub ushr 24)
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }

    /** Satu panel kaca 3x3. Dipakai untuk menu utama dan folder Lainnya. */
    private fun makePanel(items: List<Item>): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, panelColors).apply {
                cornerRadius = dp(34).toFloat()
                setStroke(dp(1), 0x59FFFFFF)
            }
        }
        for (r in 0 until 3) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 3) {
                row.addView(
                    createTile(items[r * 3 + c]),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
                )
            }
            panel.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            )
        }
        return panel
    }

    /**
     * Folder Lainnya gaya iOS: panel kedua muncul menumpuk di atas menu utama. Menu utama mengecil,
     * redup, dan bergeser ke atas sehingga tepinya masih terlihat di belakang panel baru.
     */
    private fun openSub() {
        val root = menu ?: return
        val parent = mainPanel ?: return
        if (subPanel != null) return
        val sub = makePanel(buildSubItems())
        sub.alpha = 0f
        sub.scaleX = 0.85f
        sub.scaleY = 0.85f
        root.addView(sub, FrameLayout.LayoutParams(dp(290), dp(290), Gravity.CENTER))
        subPanel = sub
        // Isi menu utama disembunyikan, hanya kartu kacanya yang tersisa di belakang panel baru.
        for (i in 0 until parent.childCount) parent.getChildAt(i).animate().alpha(0f).setDuration(160).start()
        parent.animate().scaleX(0.9f).scaleY(0.9f).translationY(-dp(26).toFloat()).alpha(0.55f)
            .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
        sub.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(220).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeSub() {
        val sub = subPanel ?: return
        subPanel = null
        mainPanel?.let { p ->
            for (i in 0 until p.childCount) p.getChildAt(i).animate().alpha(1f).setDuration(200).start()
        }
        mainPanel?.animate()?.scaleX(1f)?.scaleY(1f)?.translationY(0f)?.alpha(1f)
            ?.setDuration(200)?.setInterpolator(DecelerateInterpolator())?.start()
        sub.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(160)
            .withEndAction { menu?.removeView(sub) }.start()
    }

    /** Isi folder: slot tengah selalu Kembali, folder di dalam folder tidak diizinkan. */
    private fun buildSubItems(): List<Item> =
        Actions.load(prefs, Prefs.SLOTS_SUB, Actions.DEFAULT_SUB).mapIndexed { i, id ->
            when {
                i == Actions.CENTER ->
                    Item(R.string.label_back, R.drawable.ic_back, keepOpen = true) { closeSub() }
                id == Actions.FOLDER -> itemFor(Actions.NONE)
                else -> itemFor(id)
            }
        }

    private fun closeMenu(animate: Boolean = true) {
        val view = menu ?: return
        menu = null
        mainPanel = null
        subPanel = null
        if (animate) {
            view.animate().alpha(0f).setDuration(120).withEndAction { removeView(view) }.start()
        } else {
            view.animate().cancel()
            removeView(view)
        }
        scheduleFade()
    }

    /** Isi menu mengikuti urutan slot yang diatur pengguna (Prefs.SLOTS). */
    private fun buildItems(): List<Item> = Actions.load(prefs).map { itemFor(it) }

    private fun itemFor(id: String): Item {
        val def = Actions.find(id)
        val api28 = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
        return when (id) {
            "notifications" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            }
            "control" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            }
            "back" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            "lock" -> Item(def.label, def.icon, enabled = api28) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                }
            }
            "home" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            "recents" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
            }
            "screenshot" -> Item(def.label, def.icon, enabled = api28, delay = 380L) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    button?.visibility = View.INVISIBLE
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                    handler.postDelayed({ button?.visibility = View.VISIBLE }, 1500L)
                }
            }
            "volume" -> Item(def.label, def.icon) {
                val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_SAME,
                    AudioManager.FLAG_SHOW_UI
                )
            }
            "power" -> Item(def.label, def.icon) {
                performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            }
            "rotate" -> Item(
                if (rotateLocked()) R.string.label_rotate_locked else def.label, def.icon
            ) { toggleRotation() }
            "clean" -> Item(def.label, def.icon) {
                cleanRam { count, freed, avail -> toast(cleanMessage(count, freed, avail)) }
            }
            "boost" -> Item(
                if (boosting) R.string.label_boost_on else def.label, def.icon
            ) { toggleBoost() }
            Actions.FOLDER -> Item(def.label, def.icon, keepOpen = true) { openSub() }
            else -> Item(R.string.label_none, def.icon, enabled = false) {}
        }
    }

    // ------------------------------------------------------------ pembersih RAM

    /**
     * Menghentikan proses latar belakang aplikasi yang punya ikon peluncur (bukan aplikasi sistem)
     * dengan ActivityManager.killBackgroundProcesses. Tanpa root, jadi hanya proses di latar
     * belakang yang dihentikan: aplikasi yang sedang tampil (misalnya game) tidak tersentuh, dan
     * aplikasi dengan notifikasi foreground (pemutar musik, navigasi) umumnya bertahan.
     * Sekali jalan, tanpa timer berulang.
     */
    private fun cleanRam(onDone: (count: Int, freedMb: Int, availMb: Int) -> Unit) {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = availableMb(am)
        val count = killBackground(am)
        // Beri waktu sistem melepas memori sebelum diukur ulang.
        handler.postDelayed({
            val after = availableMb(am)
            onDone(count, maxOf(0L, after - before).toInt(), after.toInt())
        }, 700L)
    }

    @Suppress("DEPRECATION")
    private fun killBackground(am: ActivityManager): Int {
        val skip = protectedPackages()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        var count = 0
        for (ri in packageManager.queryIntentActivities(launcher, 0)) {
            val info = ri.activityInfo?.applicationInfo ?: continue
            val pkg = info.packageName
            if (pkg in skip || !seen.add(pkg)) continue
            if (info.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (info.flags and ApplicationInfo.FLAG_STOPPED != 0) continue
            try {
                am.killBackgroundProcesses(pkg)
                count++
            } catch (e: Exception) {
                // abaikan aplikasi yang menolak
            }
        }
        return count
    }

    /** Aplikasi ini sendiri, peluncur (home), keyboard aktif, dan game pilihan tidak ikut dihentikan. */
    @Suppress("DEPRECATION")
    private fun protectedPackages(): Set<String> {
        val skip = HashSet<String>()
        skip.add(packageName)
        prefs.getString(Prefs.GAME_PKG, null)?.let { skip.add(it) }
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { skip.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { skip.add(it) }
        return skip
    }

    private fun availableMb(am: ActivityManager): Long {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return info.availMem / (1024 * 1024)
    }

    private fun cleanMessage(count: Int, freedMb: Int, availMb: Int): String =
        if (freedMb > 0) getString(R.string.toast_clean_freed, count, freedMb, availMb)
        else getString(R.string.toast_clean_none, count, availMb)

    // -------------------------------------------------------------- game booster

    /**
     * Booster: bersihkan RAM, tahan layar tetap menyala selama sesi game, dan buka game pilihan
     * jika ada. Tidak bisa menaikkan CPU/GPU tanpa root. Ketuk lagi untuk mengakhiri sesi.
     */
    private fun toggleBoost() {
        if (boosting) {
            setBoost(false)
            QuietMode.exit(this)
            toast(getString(R.string.toast_boost_off))
            return
        }
        setBoost(true)
        var head = getString(R.string.toast_boost_on)
        if (prefs.getBoolean(Prefs.HIDE_NOTIF, true)) {
            val hidden = QuietMode.enter(this)
            head += "\n" + getString(if (hidden) R.string.toast_quiet_on else R.string.toast_quiet_need_access)
        }
        cleanRam { count, freed, avail ->
            toast(head + "\n" + cleanMessage(count, freed, avail))
            launchGame()
        }
    }

    private fun setBoost(on: Boolean) {
        boosting = on
        buttonLp?.let { lp ->
            lp.flags = if (on) lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            else lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
            updateButton()
        }
        button?.boosting = on
    }

    private fun launchGame() {
        val pkg = prefs.getString(Prefs.GAME_PKG, null) ?: return
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // sistem menolak membuka aplikasi dari latar belakang
        }
    }

    // ------------------------------------------------------------- kunci rotasi

    private fun rotateLocked(): Boolean = prefs.getBoolean(Prefs.ROTATE_LOCKED, false)

    private fun toggleRotation() {
        val on = !rotateLocked()
        prefs.edit().putBoolean(Prefs.ROTATE_LOCKED, on).apply()
        applyRotation()
        toast(getString(if (on) R.string.toast_rotate_on else R.string.toast_rotate_off))
    }

    /**
     * Mengunci orientasi layar lewat jendela overlay aksesibilitas berukuran 1 px yang membawa
     * screenOrientation. Tidak butuh izin WRITE_SETTINGS dan tidak menghalangi sentuhan.
     * Dilepas saat kunci dimatikan atau layanan berhenti.
     */
    private fun applyRotation() {
        if (!::wm.isInitialized || !::prefs.isInitialized) return
        removeRotation()
        if (!rotateLocked()) return
        val orientation = when (prefs.getInt(Prefs.ROTATE_MODE, Prefs.ROTATE_CURRENT)) {
            Prefs.ROTATE_PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            Prefs.ROTATE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
        }
        val lp = WindowManager.LayoutParams(
            1,
            1,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            screenOrientation = orientation
        }
        val view = View(this)
        try {
            wm.addView(view, lp)
            rotateView = view
        } catch (e: Exception) {
            // jendela ditolak
        }
    }

    private fun removeRotation() {
        rotateView?.let { removeView(it) }
        rotateView = null
    }

    private fun createTile(item: Item): View {
        val radius = dp(20).toFloat()
        val normal = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x26FFFFFF)
        }
        val pressed = GradientDrawable().apply {
            cornerRadius = radius
            setColor(0x55FFFFFF)
        }
        val label = getString(item.label)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), pressed)
                addState(intArrayOf(), normal)
            }
            alpha = if (item.enabled) 1f else 0.35f
            contentDescription = label
            if (item.enabled) {
                isClickable = true
                setOnClickListener {
                    haptic(this)
                    if (item.keepOpen) {
                        item.action()
                    } else {
                        closeMenu()
                        handler.postDelayed({ item.action() }, item.delay)
                    }
                }
            }
            addView(
                ImageView(context).apply { setImageResource(item.icon) },
                LinearLayout.LayoutParams(dp(30), dp(30))
            )
            addView(
                TextView(context).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    gravity = Gravity.CENTER
                    maxLines = 1
                    setPadding(dp(2), dp(6), dp(2), 0)
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun haptic(view: View) {
        if (prefs.getBoolean(Prefs.HAPTIC, true)) {
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun removeView(view: View) {
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // sudah dilepas
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun screenSize(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }
}
