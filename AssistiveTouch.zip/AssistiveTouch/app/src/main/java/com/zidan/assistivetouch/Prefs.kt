package com.zidan.assistivetouch

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "assistive_touch"

    const val SIZE = "size_dp"
    const val OPACITY = "idle_opacity"
    const val HAPTIC = "haptic"
    const val KEEP_ALIVE = "keep_alive"
    const val X = "pos_x"
    const val Y = "pos_y"
    const val SLOTS = "slots"
    const val SLOTS_SUB = "slots_sub"
    const val HIDE_NOTIF = "hide_notif"
    const val ANIM = "animations"
    const val GAME_PKG = "game_pkg"
    const val ROTATE_LOCKED = "rotate_locked"
    const val ROTATE_MODE = "rotate_mode"

    const val ROTATE_CURRENT = 0
    const val ROTATE_PORTRAIT = 1
    const val ROTATE_LANDSCAPE = 2

    const val DEFAULT_SIZE = 56
    const val DEFAULT_OPACITY = 60

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
