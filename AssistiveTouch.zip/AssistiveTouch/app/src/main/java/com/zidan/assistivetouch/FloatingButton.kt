package com.zidan.assistivetouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/**
 * Tombol melayang bulat: lingkaran gelap dengan dua cincin abu-abu dan inti putih.
 * Digambar langsung dengan Canvas, tanpa bitmap, sehingga hampir tidak memakai memori.
 */
class FloatingButton(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    private val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF222A32.toInt() }
    private val ringOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5E666B.toInt() }
    private val ringInner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8D949A.toInt() }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val coreEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density * 0.8f
        color = 0x40000000
    }

    /** Booster aktif: inti tombol berubah hijau sebagai penanda. */
    var boosting: Boolean = false
        set(value) {
            field = value
            core.color = if (value) 0xFF30D158.toInt() else 0xFFFFFFFF.toInt()
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val c = width / 2f
        val r = c - density
        canvas.drawCircle(c, c, r, outer)
        canvas.drawCircle(c, c, r * 0.727f, ringOuter)
        canvas.drawCircle(c, c, r * 0.61f, ringInner)
        canvas.drawCircle(c, c, r * 0.48f, core)
        canvas.drawCircle(c, c, r * 0.48f, coreEdge)
    }
}
