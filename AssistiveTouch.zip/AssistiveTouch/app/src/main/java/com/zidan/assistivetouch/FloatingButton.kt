package com.zidan.assistivetouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/**
 * Tombol melayang bergaya iOS: kotak membulat kaca gelap dengan lingkaran konsentris.
 * Digambar langsung dengan Canvas, tanpa bitmap, sehingga hampir tidak memakai memori.
 */
class FloatingButton(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    private val glass = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glassEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density
        color = 0x66FFFFFF
    }
    private val outerRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x30FFFFFF }
    private val outerRingEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = density * 1.2f
        color = 0x88FFFFFF.toInt()
    }
    private val core = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2FFFFFF.toInt() }
    private val bounds = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        glass.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            0x9A4A4A56.toInt(), 0x9A1C1C24.toInt(),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val inset = density
        bounds.set(inset, inset, w - inset, height - inset)
        val corner = w * 0.3f
        canvas.drawRoundRect(bounds, corner, corner, glass)
        canvas.drawRoundRect(bounds, corner, corner, glassEdge)

        val c = w / 2f
        canvas.drawCircle(c, c, w * 0.32f, outerRing)
        canvas.drawCircle(c, c, w * 0.32f, outerRingEdge)
        canvas.drawCircle(c, c, w * 0.19f, core)
    }
}
